from pydantic import BaseModel, Field
from typing import Dict, Any

class PlanSchema(BaseModel):
    project_name: str
    component_name: str
    environment: str
    terraform_plan: Dict[str, Any]
