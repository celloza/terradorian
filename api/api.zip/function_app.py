import azure.functions as func
import logging
import json
import uuid
from datetime import datetime
from pydantic import ValidationError
from models import PlanSchema

app = func.FunctionApp()

@app.route(route="ingest_plan", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
@app.cosmos_db_output(
    arg_name="outputDocument",
    database_name="TerradorianDB",
    container_name="plans",
    connection="CosmosDbConnectionSetting",
    create_if_not_exists=True
)
def ingest_plan(req: func.HttpRequest, outputDocument: func.Out[func.Document]) -> func.HttpResponse:
    logging.info('Processing ingest_plan request.')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            "Invalid JSON body",
            status_code=400
        )

    try:
        # Validate payload with Pydantic
        plan_data = PlanSchema(**req_body)
    except ValidationError as e:
        return func.HttpResponse(
            f"Validation Error: {e.json()}",
            status_code=400,
            mimetype="application/json"
        )

    # Prepare document for Cosmos DB
    doc_dict = plan_data.model_dump()
    doc_dict['id'] = str(uuid.uuid4())
    doc_dict['timestamp'] = datetime.utcnow().isoformat()

    # The user wants to track drift over time, so we insert a new record each time.
    # Output binding acts as upsert based on 'id'. Since 'id' is random UUID, this is an insert.
    
    try:
        outputDocument.set(func.Document.from_dict(doc_dict))
    except Exception as e:
        logging.error(f"Error saving to Cosmos DB: {e}")
        return func.HttpResponse(
            "Internal Server Error while saving data.",
            status_code=500
        )

    return func.HttpResponse(
        body=json.dumps({"id": doc_dict['id'], "message": "Plan ingested successfully"}),
        status_code=201,
        mimetype="application/json"
    )
